﻿' option Explicit on
' option Strict on   


Imports System
Imports MarsRoverUltimate.MarsRover


Namespace MarsRover

    Public Interface IPlateau
        Property X As Integer
        Property Y As Integer

    End Interface
End Namespace

